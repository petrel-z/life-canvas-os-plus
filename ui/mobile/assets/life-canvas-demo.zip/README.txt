This is a UI demonstration fixture. Do not import it into production.
